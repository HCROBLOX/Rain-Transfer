package com.hcroblox.raintransfer

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.View
import android.view.Gravity
import android.webkit.*
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.net.wifi.WifiManager
import android.provider.OpenableColumns
import java.io.*
import java.net.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var server: LanServer
    private lateinit var web: WebView
    private lateinit var codeLabel: TextView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var multicastLock: WifiManager.MulticastLock? = null
    private val pickFile = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(8, 16, 31)
        window.navigationBarColor = Color.rgb(8, 16, 31)
        window.decorView.systemUiVisibility = 0

        val pin = (100000..999999).random().toString()
        server = LanServer(this, pin)
        server.start()
        try {
            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            multicastLock = wifi.createMulticastLock("RainTransferDiscovery").apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) { }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(8, 16, 31))
        }
        codeLabel = TextView(this).apply {
            text = "RAIN TRANSFER  •  MÃ PIN: $pin\nĐịa chỉ chia sẻ đang khởi động…"
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER_VERTICAL
            setPadding(20, 12, 20, 12)
            setBackgroundColor(Color.rgb(15, 31, 55))
        }
        root.addView(codeLabel, LinearLayout.LayoutParams(-1, -2))
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = false
            settings.allowContentAccess = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webChromeClient = object : WebChromeClient() {
                override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = callback
                    val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                        addCategory(Intent.CATEGORY_OPENABLE)
                        type = "*/*"
                        putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                    }
                    startActivityForResult(intent, pickFile)
                    return true
                }
            }
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    val ip = server.localIp()
                    codeLabel.text = "RAIN TRANSFER  •  MÃ PIN: $pin\nMở trên thiết bị khác: http://$ip:8765"
                }
            }
            loadUrl("http://127.0.0.1:8765/")
        }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickFile) {
            val results = if (resultCode == RESULT_OK && data != null) {
                val clip = data.clipData
                if (clip != null) Array(clip.itemCount) { i -> clip.getItemAt(i).uri }
                else data.data?.let { arrayOf(it) }
            } else null
            fileCallback?.onReceiveValue(results)
            fileCallback = null
        }
    }

    override fun onDestroy() {
        try { multicastLock?.release() } catch (_: Exception) { }
        server.stop()
        web.destroy()
        super.onDestroy()
    }
}

private data class Peer(val id: String, val name: String, val ip: String, val port: Int, val seen: Long)

private class LanServer(private val context: Context, private val pin: String) {
    private val port = 8765
    private val discoveryPort = 37021
    private val id = UUID.randomUUID().toString().take(8)
    private val peers = ConcurrentHashMap<String, Peer>()
    private val receivedDir = File(context.getExternalFilesDir(null) ?: context.filesDir, "RainTransfer/Received").apply { mkdirs() }
    @Volatile private var running = false
    private var serverSocket: ServerSocket? = null
    private var udpSocket: DatagramSocket? = null
    private var multicastThread: Thread? = null
    private var acceptThread: Thread? = null

    fun start() {
        if (running) return
        running = true
        val ready = CountDownLatch(1)
        acceptThread = thread(name = "RainHttp") {
            try {
                serverSocket = ServerSocket(port, 50, InetAddress.getByName("0.0.0.0"))
                ready.countDown()
                while (running) {
                    val client = serverSocket!!.accept()
                    thread(name = "RainClient") { handle(client) }
                }
            } catch (_: Exception) { ready.countDown() }
        }
        try { ready.await(2, java.util.concurrent.TimeUnit.SECONDS) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        multicastThread = thread(name = "RainDiscovery") { discoveryLoop() }
    }

    fun stop() {
        running = false
        try { serverSocket?.close() } catch (_: Exception) { }
        try { udpSocket?.close() } catch (_: Exception) { }
    }

    fun localIp(): String {
        try {
            val all = NetworkInterface.getNetworkInterfaces().toList().filter { it.isUp && !it.isLoopback }
            val preferred = all.sortedBy { ni ->
                val n = ni.name.lowercase()
                if (n.startsWith("wlan") || n.startsWith("wifi") || n.startsWith("ap")) 0 else 1
            }
            for (ni in preferred) {
                val addresses = ni.inetAddresses
                while (addresses.hasMoreElements()) {
                    val a = addresses.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress && !a.isLinkLocalAddress) return a.hostAddress ?: "127.0.0.1"
                }
            }
        } catch (_: Exception) { }
        return "127.0.0.1"
    }

    private fun discoveryLoop() {
        try {
            udpSocket = DatagramSocket(null).apply { reuseAddress = true; broadcast = true; bind(InetSocketAddress(discoveryPort)) }
            val sock = udpSocket!!
            sock.soTimeout = 1200
            val buf = ByteArray(1024)
            while (running) {
                val message = "RAINTRANSFER|$id|${localIp()}|$port|${android.os.Build.MODEL}".toByteArray()
                try { sock.send(DatagramPacket(message, message.size, InetAddress.getByName("255.255.255.255"), discoveryPort)) } catch (_: Exception) { }
                val packet = DatagramPacket(buf, buf.size)
                try {
                    sock.receive(packet)
                    val parts = String(packet.data, 0, packet.length).split('|')
                    if (parts.size >= 5 && parts[0] == "RAINTRANSFER" && parts[1] != id) {
                        peers[parts[1]] = Peer(parts[1], parts[4].take(40), packet.address.hostAddress ?: parts[2], parts[3].toIntOrNull() ?: port, System.currentTimeMillis())
                    }
                } catch (_: SocketTimeoutException) { } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
    }

    private fun handle(socket: Socket) {
        socket.use { s ->
            s.soTimeout = 30000
            val input = BufferedInputStream(s.getInputStream())
            val output = BufferedOutputStream(s.getOutputStream())
            try {
                val headerBytes = ByteArrayOutputStream()
                var state = 0
                while (headerBytes.size() < 32768) {
                    val b = input.read(); if (b < 0) return
                    headerBytes.write(b)
                    state = when {
                        state == 0 && b == 13 -> 1
                        state == 1 && b == 10 -> 2
                        state == 2 && b == 13 -> 3
                        state == 3 && b == 10 -> 4
                        b == 13 -> 1
                        else -> 0
                    }
                    if (state == 4) break
                }
                val headerText = headerBytes.toString(Charsets.ISO_8859_1.name())
                val lines = headerText.split("\r\n")
                val first = lines.firstOrNull()?.split(' ') ?: return
                if (first.size < 2) return
                val method = first[0]
                val target = first[1]
                val headers = lines.drop(1).mapNotNull { line ->
                    val ix = line.indexOf(':'); if (ix > 0) line.substring(0, ix).trim().lowercase() to line.substring(ix + 1).trim() else null
                }.toMap()
                val length = headers["content-length"]?.toLongOrNull() ?: 0L
                val path = target.substringBefore('?')
                val query = target.substringAfter('?', "")
                val params = query.split('&').filter { it.contains('=') }.associate { URLDecoder.decode(it.substringBefore('='), "UTF-8") to URLDecoder.decode(it.substringAfter('='), "UTF-8") }

                if (method == "OPTIONS") { respond(output, 204, "", "text/plain"); return }
                if (path == "/" || path == "/index.html") {
                    val html = context.assets.open("index.html").bufferedReader().use { it.readText() }
                    respond(output, 200, html, "text/html; charset=utf-8"); return
                }
                if (path == "/style.css" || path == "/app.js") {
                    val name = path.removePrefix("/")
                    val content = context.assets.open(name).bufferedReader().use { it.readText() }
                    respond(output, 200, content, if (name.endsWith(".css")) "text/css" else "application/javascript"); return
                }
                if (!authorized(headers)) { respond(output, 401, "{\"error\":\"Mã ghép nối không đúng\"}", "application/json"); return }
                when {
                    path == "/api/info" -> {
                        val json = "{\"name\":\"${jsonEscape(android.os.Build.MODEL)}\",\"ip\":\"${localIp()}\",\"port\":$port,\"peers\":${peerJson()}}"
                        respond(output, 200, json, "application/json")
                    }
                    path == "/api/files" -> {
                        val files = receivedDir.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() } ?: emptyList()
                        val json = files.joinToString(prefix = "[", postfix = "]") { "{\"name\":\"${jsonEscape(it.name)}\",\"size\":${it.length()},\"modified\":${it.lastModified()}}" }
                        respond(output, 200, json, "application/json")
                    }
                    path == "/upload" && method == "POST" -> {
                        val rawName = params["name"] ?: "received_file"
                        val safeName = safeFileName(rawName)
                        val dest = uniqueFile(safeName)
                        FileOutputStream(dest).use { fos ->
                            val buffer = ByteArray(64 * 1024); var remaining = length
                            while (remaining > 0) {
                                val n = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                                if (n < 0) throw EOFException("Upload ended early")
                                fos.write(buffer, 0, n); remaining -= n
                            }
                        }
                        respond(output, 201, "{\"ok\":true,\"name\":\"${jsonEscape(dest.name)}\",\"size\":${dest.length()}}", "application/json")
                    }
                    path == "/download" -> {
                        val file = File(receivedDir, safeFileName(params["name"] ?: ""))
                        if (!file.isFile || !file.canonicalPath.startsWith(receivedDir.canonicalPath + File.separator)) {
                            respond(output, 404, "Not found", "text/plain")
                        } else {
                            val header = "HTTP/1.1 200 OK\r\nContent-Type: application/octet-stream\r\nContent-Length: ${file.length()}\r\nContent-Disposition: attachment; filename*=UTF-8''${URLEncoder.encode(file.name, "UTF-8")}\r\nConnection: close\r\n\r\n"
                            output.write(header.toByteArray(Charsets.ISO_8859_1)); FileInputStream(file).use { it.copyTo(output) }; output.flush()
                        }
                    }
                    else -> respond(output, 404, "Not found", "text/plain")
                }
            } catch (e: Exception) {
                try { respond(output, 500, "{\"error\":\"${jsonEscape(e.message ?: "Lỗi truyền dữ liệu")}\"}", "application/json") } catch (_: Exception) { }
            }
        }
    }

    private fun authorized(headers: Map<String, String>) = headers["x-rain-pin"] == pin
    private fun peerJson(): String {
        val now = System.currentTimeMillis()
        peers.entries.removeIf { now - it.value.seen > 15000 }
        return peers.values.joinToString(prefix = "[", postfix = "]") { "{\"name\":\"${jsonEscape(it.name)}\",\"ip\":\"${it.ip}\",\"port\":${it.port}}" }
    }
    private fun uniqueFile(name: String): File {
        var f = File(receivedDir, name); var n = 1
        while (f.exists()) { val dot = name.lastIndexOf('.'); val base = if (dot > 0) name.substring(0, dot) else name; val ext = if (dot > 0) name.substring(dot) else ""; f = File(receivedDir, "$base ($n)$ext"); n++ }
        return f
    }
    private fun safeFileName(name: String) = name.substringAfterLast('/').substringAfterLast('\\').replace(Regex("[^\\p{L}\\p{N} ._()\\-]"), "_").trim().take(180).ifBlank { "received_file" }
    private fun jsonEscape(s: String) = s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "")
    private fun respond(out: OutputStream, status: Int, body: String, type: String) {
        val bytes = body.toByteArray(Charsets.UTF_8)
        val label = when (status) { 200 -> "OK"; 201 -> "Created"; 204 -> "No Content"; 401 -> "Unauthorized"; 404 -> "Not Found"; else -> "Internal Server Error" }
        val header = "HTTP/1.1 $status $label\r\nContent-Type: $type\r\nContent-Length: ${bytes.size}\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: Content-Type, X-Rain-Pin\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nConnection: close\r\n\r\n"
        out.write(header.toByteArray(Charsets.ISO_8859_1)); out.write(bytes); out.flush()
    }
}
