# Rain Transfer

Ứng dụng chia sẻ tệp qua mạng Wi-Fi nội bộ, gồm ứng dụng Android và giao diện web dùng được trên thiết bị có trình duyệt.

## Tính năng trong bản 1.0

- Máy Android chạy ứng dụng sẽ mở máy chủ HTTP nội bộ trên cổng `8765`.
- Các ứng dụng Rain Transfer Android khác tự quảng bá và phát hiện nhau qua UDP broadcast trên cổng `37021`.
- Windows, iPhone, iPad và thiết bị khác có trình duyệt tham gia bằng cách mở địa chỉ LAN hiển thị trên màn hình Android chủ.
- Gửi nhiều tệp bất kỳ qua HTTP streaming; có thanh tiến trình trên giao diện.
- Danh sách và tải xuống các tệp đã nhận.
- Mã ghép nối 6 chữ số được hiển thị trên thiết bị chủ; mọi API truyền/đọc tệp yêu cầu mã này.
- Giao diện tối/sáng, bố cục thích ứng điện thoại và máy tính.

## Cách dùng

1. Cài và mở Rain Transfer trên điện thoại Android chủ.
2. Kết nối các thiết bị vào cùng Wi-Fi; không bật mạng khách (Guest Wi-Fi) có chặn thiết bị nội bộ.
3. Trên máy tính/iPhone, mở trình duyệt và nhập địa chỉ `http://IP_CUA_DIEN_THOAI:8765` hiển thị trong ứng dụng.
4. Nhập mã 6 chữ số đang hiển thị trên điện thoại chủ.
5. Chọn tệp để gửi. Tệp nhận được lưu trong thư mục riêng của ứng dụng: `Android/data/com.hcroblox.raintransfer/files/RainTransfer/Received`.

## Biên dịch APK

Yêu cầu Android Studio hoặc Android SDK, JDK 17, Gradle tương thích Android Gradle Plugin 8.7.3.

```bash
gradle assembleDebug
```

APK debug sẽ nằm tại `app/build/outputs/apk/debug/app-debug.apk`.

## Lưu ý về kết nối và bảo mật

- Đây là bản LAN: dữ liệu truyền trong mạng Wi-Fi, không dùng máy chủ Internet hoặc tài khoản.
- Phần tự tìm thiết bị dùng UDP broadcast. Một số router, Wi-Fi khách, VPN hoặc điểm phát sóng có thể chặn broadcast/client isolation. Khi đó vẫn có thể mở địa chỉ IP thủ công.
- Trình duyệt không được phép tự nghe UDP broadcast. Vì vậy Windows/iPhone tham gia bằng địa chỉ IP + mã ghép nối, không tự xuất hiện trong danh sách phát hiện Android.
- Mã ghép nối là lớp xác nhận cơ bản trong mạng nội bộ; bản này chưa mã hóa đầu cuối TLS. Chỉ chia sẻ mã với người tin cậy và không dùng trên Wi-Fi công cộng.
- Máy chủ chỉ hoạt động khi ứng dụng đang mở. Android có thể tạm dừng mạng khi ứng dụng chạy nền hoặc màn hình tắt.
- Bản này lưu tệp trong vùng dữ liệu riêng của ứng dụng; gỡ ứng dụng có thể xóa các tệp đó.
- Chưa có kiểm thử thực tế trên nhiều hãng router/điện thoại. Không thể cam kết không phát sinh lỗi trên mọi mạng.

## Cấu trúc

- `app/src/main/java/.../MainActivity.kt`: máy chủ HTTP, phát hiện thiết bị LAN và WebView Android.
- `app/src/main/assets/`: giao diện web responsive.
- `app/src/main/AndroidManifest.xml`: quyền mạng và cấu hình ứng dụng.

## Tự động tạo APK bằng GitHub Actions

Dự án có workflow tại `.github/workflows/android-apk.yml`. Sau khi đưa mã nguồn lên GitHub, mở tab **Actions** và chạy workflow **Build Rain Transfer APK**. Khi hoàn tất, tải artifact `Rain-Transfer-debug-apk` để lấy APK debug.
